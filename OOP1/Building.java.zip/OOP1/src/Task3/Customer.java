package Task3;

public class Customer {


    public String firstName;

    private String lastName;

    private String userName;

    //Constructor
    public Customer(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
    }




    public String toString(){return "name ="+ firstName+ "username =" + userName;};

    private void setLastName(String lastName){
        this.lastName=lastName;
        }
}














