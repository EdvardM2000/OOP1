package Task3;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {


        Customer customer1 = new Customer("John", "Smith");


        // ArrayList = 	a resizable array.
        //				Elements can be added and removed after compilation phase
        //				store reference data types
    }}

